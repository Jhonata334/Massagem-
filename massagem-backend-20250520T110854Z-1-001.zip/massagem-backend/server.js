
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
const PORT = 3001;
const codigos = {};

app.use(cors());
app.use(express.json());

const transporter = nodemailer.createTransport({
    host: 'smtp.office365.com',
    port: 587,
    secure: false,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    },
    tls: {
        ciphers: 'SSLv3'
    }
});

app.post('/enviar-codigo', (req, res) => {
    const { email } = req.body;
    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    codigos[email] = codigo;

    const mailOptions = {
        from: `"Massagem RH" <${process.env.EMAIL_USER}>`,
        to: email,
        subject: 'Código de Confirmação',
        text: `Seu código de confirmação é: ${codigo}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
            return res.status(500).send("Erro ao enviar e-mail.");
        }
        res.send("Código enviado com sucesso.");
    });
});

app.post('/verificar-codigo', (req, res) => {
    const { email, codigo } = req.body;
    if (codigos[email] === codigo) {
        delete codigos[email];
        return res.send("Código verificado com sucesso!");
    }
    res.status(400).send("Código inválido.");
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
