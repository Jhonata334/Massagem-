const nodemailer = require("nodemailer");
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let codigoVerificacao = ""; // Em produção, use algo mais seguro.

app.post("/enviar-codigo", async (req, res) => {
    const { email, codigo } = req.body;

    // Configure com e-mail da empresa
    let transporter = nodemailer.createTransport({
        host: "smtp.office365.com",
        port: 587,
        secure: false,
        auth: {
            user: "email@empresa.com.br",
            pass: "SENHA_DO_EMAIL"
        }
    });

    try {
        await transporter.sendMail({
            from: '"Equipe Massagem" <email@empresa.com.br>',
            to: email,
            subject: "Código de Confirmação",
            text: `Seu código de confirmação é: ${codigo}`
        });

        res.status(200).send({ status: "enviado" });
    } catch (err) {
        console.error(err);
        res.status(500).send({ status: "erro", mensagem: err.message });
    }
});

const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
